<?php
/**
 * @brief		Payssion Gateway Application Class
 * @author		<a href=''>Ahmad E.</a>
 * @copyright	(c) 2019 Ahmad E.
 * @package		Invision Community
 * @subpackage	Payssion Gateway
 * @since		08 Mar 2019
 * @version		
 */
 
namespace IPS\payssion;

/**
 * Payssion Gateway Application Class
 */
class _Application extends \IPS\Application
{
	
}