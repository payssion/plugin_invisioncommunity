<?php

$lang = array(
	'__app_payssion'	=> "Payssion Gateway",
    'gateway__Payssion' => "Payssion",
    'payssion_api_key'  => "API Key",
    'payssion_api_key_desc'  => "API Key of your <a href='https://www.payssion.com/account/app' target='_blank'>Payssion APP</a>",
    'payssion_secret_key'   => "Secret Key",
    'payssion_secret_key_desc' => "Secret Key of your <a href='https://www.payssion.com/account/app' target='_blank'>Payssion APP</a>",
    'payssion_payment_methods'  => "Payment Methods",
    'payssion_payment_methods_desc' => "Payment Methods that you want to accept",
    'payssion_pmid' => "Payment Method",
);
